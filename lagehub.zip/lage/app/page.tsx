import { clientes, videos, tarefas } from "@/lib/mock-data";
import { getInitials } from "@/lib/utils";
import { Video, Tarefa } from "@/types";
import { Crown, Video as VideoIcon, Zap, Users, ClipboardList, ExternalLink } from "lucide-react";

const ESTAGIOS = [
  { nome: "Embalagem", cor: "#F59E0B" },
  { nome: "Aprovação Big Idea", cor: "#8B5CF6" },
  { nome: "Gravação", cor: "#10B981" },
  { nome: "Roteiro", cor: "#3B82F6" },
  { nome: "Postagem", cor: "#EC4899" },
  { nome: "Gravação e Mineração", cor: "#06B6D4" },
  { nome: "Edição", cor: "#F97316" },
  { nome: "Aprovação Roteiro", cor: "#84CC16" },
  { nome: "Concluído", cor: "#6B7280" },
];

function StatusBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    Pendente: "bg-gray-100 text-gray-700",
    "Em Progresso": "bg-blue-100 text-blue-700",
    Concluído: "bg-green-100 text-green-700",
    Atrasado: "bg-red-100 text-red-700",
  };
  return (
    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${colors[status] || "bg-gray-100 text-gray-600"}`}>
      {status}
    </span>
  );
}

export default function DashboardPage() {
  const totalVideos = videos.length;
  const emProducao = videos.filter((v) => v.estagio !== "Concluído").length;
  const clientesAtivos = clientes.filter((c) => c.ativo).length;
  const totalTarefas = tarefas.length;

  const concluidos = videos.filter((v) => v.estagio === "Concluído").length;
  const progressoGeral = Math.round((concluidos / totalVideos) * 100);

  const hoje = new Date();
  const tarefasHoje = tarefas.slice(0, 15);
  const proximasTarefas = tarefas.filter((t) => t.status === "Pendente" || t.status === "Atrasado").slice(0, 5);

  const videosRecentes = [...videos]
    .sort((a, b) => new Date(b.criadoEm).getTime() - new Date(a.criadoEm).getTime())
    .slice(0, 5);

  const stats = [
    { label: "Total de Vídeos", value: totalVideos, sub: "vídeos cadastrados", icon: VideoIcon, color: "text-blue-600", bg: "bg-blue-50" },
    { label: "Em Produção", value: emProducao, sub: "vídeos sendo produzidos", icon: Zap, color: "text-orange-600", bg: "bg-orange-50" },
    { label: "Clientes Ativos", value: clientesAtivos, sub: "clientes cadastrados", icon: Users, color: "text-green-600", bg: "bg-green-50" },
    { label: "Tarefas Gerais", value: totalTarefas, sub: "total pendentes", icon: ClipboardList, color: "text-red-600", bg: "bg-red-50" },
  ];

  return (
    <div className="p-6 max-w-[1400px] mx-auto">
      {/* Banner */}
      <div className="bg-gradient-to-r from-violet-600 to-violet-800 rounded-xl p-5 mb-6 flex items-center justify-between">
        <div>
          <p className="text-violet-200 text-sm font-medium">Bem-vindo</p>
          <h1 className="text-white text-2xl font-bold">Lage Hub</h1>
          <p className="text-violet-200 text-sm">Gerencie toda a plataforma e equipe</p>
        </div>
        <Crown size={40} className="text-violet-300" />
      </div>

      {/* Data */}
      <div className="mb-5 flex items-center justify-between">
        <p className="text-gray-500 text-sm">
          {hoje.toLocaleDateString("pt-BR", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        {stats.map((s) => (
          <div key={s.label} className="bg-white rounded-xl border border-gray-100 p-4 flex items-center gap-4 shadow-sm">
            <div className={`w-12 h-12 rounded-xl ${s.bg} flex items-center justify-center`}>
              <s.icon size={22} className={s.color} />
            </div>
            <div>
              <p className="text-gray-500 text-xs">{s.label}</p>
              <p className="text-2xl font-bold text-gray-900">{s.value}</p>
              <p className="text-gray-400 text-xs">{s.sub}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Left: Pipeline + Chart + Recent */}
        <div className="col-span-2 space-y-5">
          {/* Pipeline */}
          <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-semibold text-gray-900">Pipeline de Produção</h2>
              <span className="text-violet-600 text-sm font-medium">{progressoGeral}% de conclusão</span>
            </div>
            <div className="w-full bg-gray-100 rounded-full h-2 mb-5">
              <div className="bg-violet-600 h-2 rounded-full transition-all" style={{ width: `${progressoGeral}%` }} />
            </div>
            <div className="space-y-3">
              {ESTAGIOS.map((estagio) => {
                const count = videos.filter((v) => v.estagio === estagio.nome).length;
                const pct = totalVideos > 0 ? Math.round((count / totalVideos) * 100) : 0;
                return (
                  <div key={estagio.nome} className="flex items-center gap-3">
                    <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: estagio.cor }} />
                    <span className="text-sm text-gray-700 w-44">{estagio.nome}</span>
                    <div className="flex-1 bg-gray-100 rounded-full h-1.5">
                      <div className="h-1.5 rounded-full" style={{ width: `${pct}%`, backgroundColor: estagio.cor }} />
                    </div>
                    <span className="text-xs text-gray-500 w-16 text-right">{count} vídeos · {pct}%</span>
                  </div>
                );
              })}
            </div>
            <div className="flex gap-8 mt-4 pt-4 border-t border-gray-100">
              <div className="text-center"><p className="text-2xl font-bold text-gray-900">{emProducao}</p><p className="text-xs text-gray-500">Em Produção</p></div>
              <div className="text-center"><p className="text-2xl font-bold text-gray-900">{concluidos}</p><p className="text-xs text-gray-500">Concluído</p></div>
              <div className="text-center"><p className="text-2xl font-bold text-gray-900">{totalVideos}</p><p className="text-xs text-gray-500">Total</p></div>
            </div>
          </div>

          {/* Videos Recentes */}
          <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-sm">
            <h2 className="font-semibold text-gray-900 mb-3">Vídeos Recentes</h2>
            <div className="space-y-2">
              {videosRecentes.map((v) => {
                const cliente = clientes.find((c) => c.id === v.clienteId);
                return (
                  <div key={v.id} className="flex items-center gap-3 py-2 border-b border-gray-50 last:border-0">
                    <VideoIcon size={16} className="text-gray-400 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-gray-800 truncate">{v.titulo}</p>
                      <p className="text-xs text-gray-400">{cliente?.nome} · {new Date(v.criadoEm).toLocaleDateString("pt-BR")}</p>
                    </div>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-violet-100 text-violet-700 flex-shrink-0">{v.estagio}</span>
                  </div>
                );
              })}
            </div>
            <button className="text-violet-600 text-sm font-medium mt-3 hover:underline">Ver todos os vídeos</button>
          </div>
        </div>

        {/* Right: Tarefas */}
        <div className="space-y-5">
          {/* Tarefas do Dia */}
          <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-sm">
            <h2 className="font-semibold text-gray-900 mb-1">Tarefas do Dia</h2>
            <p className="text-gray-400 text-xs mb-3">{tarefasHoje.length} atividades programadas para hoje</p>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {tarefasHoje.map((t) => {
                const cliente = clientes.find((c) => c.id === t.clienteId);
                return (
                  <div key={t.id} className="border border-gray-100 rounded-lg p-3">
                    <div className="flex items-center gap-2 mb-1.5">
                      <div className="w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0" style={{ backgroundColor: cliente?.cor }}>
                        {getInitials(cliente?.nome || "")}
                      </div>
                      <span className="text-xs px-2 py-0.5 rounded bg-gray-100 text-gray-600">{t.tipo}</span>
                    </div>
                    <p className="text-xs text-gray-700 mb-2 line-clamp-2">{t.titulo}</p>
                    <div className="flex items-center gap-2">
                      <button className="flex-1 bg-violet-600 text-white text-xs py-1.5 rounded-md hover:bg-violet-700 transition-colors">
                        Entregar
                      </button>
                      <button className="p-1.5 rounded-md hover:bg-gray-100 transition-colors">
                        <ExternalLink size={13} className="text-gray-400" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
            <button className="text-violet-600 text-sm font-medium mt-3 hover:underline">Ver todas as minhas tarefas</button>
          </div>

          {/* Proximas Tarefas */}
          <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-sm">
            <h2 className="font-semibold text-gray-900 mb-1">Próximas Tarefas</h2>
            <p className="text-gray-400 text-xs mb-3">Para tarefas mais urgentes</p>
            <div className="space-y-2">
              {proximasTarefas.map((t) => (
                <div key={t.id} className="flex items-center gap-3 py-1.5 border-b border-gray-50 last:border-0">
                  <div className="w-2 h-2 rounded-full bg-red-400 flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-gray-700 truncate">{t.tipo}</p>
                    <p className="text-xs text-gray-400 truncate">{t.titulo}</p>
                  </div>
                  <StatusBadge status={t.status} />
                </div>
              ))}
            </div>
            <button className="text-violet-600 text-sm font-medium mt-3 hover:underline">Ver todas as tarefas ({totalTarefas})</button>
          </div>

          {/* Admin */}
          <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-sm">
            <h2 className="font-semibold text-gray-900 mb-1">Administração</h2>
            <p className="text-gray-400 text-xs mb-3">Configurações da plataforma</p>
            <div className="space-y-1">
              {["Gerenciar Usuários", "Gerenciar Clientes", "Calendário"].map((item) => (
                <button key={item} className="w-full text-left text-sm text-gray-600 hover:text-violet-600 hover:bg-violet-50 px-3 py-2 rounded-md transition-colors">
                  → {item}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
