'use client'

import { useState } from 'react'
import { ChevronLeft, ChevronRight, Calendar } from 'lucide-react'
import { videos, clientes } from '@/lib/mock-data'
import { getClienteById } from '@/lib/utils'
import { format, startOfMonth, endOfMonth, eachDayOfInterval, startOfWeek, endOfWeek, isSameMonth, isToday, isSameDay } from 'date-fns'
import { ptBR } from 'date-fns/locale'

export default function CalendarioPage() {
  const [currentDate, setCurrentDate] = useState(new Date(2026, 6, 1))
  const [selectedDate, setSelectedDate] = useState<Date | null>(null)

  const monthStart = startOfMonth(currentDate)
  const monthEnd = endOfMonth(currentDate)
  const calStart = startOfWeek(monthStart, { weekStartsOn: 0 })
  const calEnd = endOfWeek(monthEnd, { weekStartsOn: 0 })
  const days = eachDayOfInterval({ start: calStart, end: calEnd })

  const getVideosForDay = (day: Date) =>
    videos.filter(v => v.dataPostagem && isSameDay(new Date(v.dataPostagem), day))

  const selectedDayVideos = selectedDate ? getVideosForDay(selectedDate) : []

  const weekDays = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb']

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Calendário</h1>
        <div className="flex items-center gap-3">
          <button onClick={() => setCurrentDate(new Date(2026, 6, 1))}
            className="px-3 py-1.5 border border-gray-200 rounded-lg text-sm text-gray-600 hover:bg-gray-50 transition-colors">
            Hoje
          </button>
          <div className="flex items-center gap-1">
            <button onClick={() => setCurrentDate(d => new Date(d.getFullYear(), d.getMonth() - 1, 1))}
              className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors"><ChevronLeft className="w-4 h-4" /></button>
            <span className="text-sm font-semibold text-gray-700 min-w-32 text-center">
              {format(currentDate, 'MMMM yyyy', { locale: ptBR })}
            </span>
            <button onClick={() => setCurrentDate(d => new Date(d.getFullYear(), d.getMonth() + 1, 1))}
              className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors"><ChevronRight className="w-4 h-4" /></button>
          </div>
        </div>
      </div>

      <div className="flex gap-4">
        <div className="flex-1 bg-white rounded-xl border border-gray-200 overflow-hidden">
          <div className="grid grid-cols-7 border-b border-gray-200">
            {weekDays.map(d => (
              <div key={d} className="py-2 text-center text-xs font-semibold text-gray-500">{d}</div>
            ))}
          </div>
          <div className="grid grid-cols-7">
            {days.map((day, i) => {
              const dayVideos = getVideosForDay(day)
              const inMonth = isSameMonth(day, currentDate)
              const today = isToday(day)
              const selected = selectedDate && isSameDay(day, selectedDate)
              return (
                <div key={i} onClick={() => setSelectedDate(day)}
                  className={`min-h-24 p-1.5 border-b border-r border-gray-100 cursor-pointer transition-colors ${inMonth ? 'bg-white hover:bg-gray-50' : 'bg-gray-50'} ${selected ? 'ring-2 ring-inset ring-violet-500' : ''}`}>
                  <div className={`w-6 h-6 flex items-center justify-center rounded-full text-xs font-medium mb-1 ${today ? 'bg-violet-600 text-white' : inMonth ? 'text-gray-700' : 'text-gray-300'}`}>
                    {format(day, 'd')}
                  </div>
                  <div className="space-y-0.5">
                    {dayVideos.slice(0, 3).map(v => {
                      const cliente = getClienteById(clientes, v.clienteId)
                      return (
                        <div key={v.id} className="text-xs px-1 py-0.5 rounded truncate text-white"
                          style={{ backgroundColor: cliente?.cor || '#7C3AED' }}>
                          {v.titulo}
                        </div>
                      )
                    })}
                    {dayVideos.length > 3 && (
                      <div className="text-xs text-gray-400 px-1">+{dayVideos.length - 3} mais</div>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        <div className="w-72 bg-white rounded-xl border border-gray-200 p-4">
          {selectedDate ? (
            <>
              <h3 className="font-semibold text-gray-900 mb-3">
                {format(selectedDate, "d 'de' MMMM", { locale: ptBR })}
              </h3>
              {selectedDayVideos.length === 0 ? (
                <div className="text-center py-8 text-gray-400">
                  <Calendar className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">Nenhum vídeo neste dia</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {selectedDayVideos.map(v => {
                    const cliente = getClienteById(clientes, v.clienteId)
                    return (
                      <div key={v.id} className="p-3 rounded-lg border border-gray-100 bg-gray-50">
                        <p className="text-sm font-medium text-gray-800">{v.titulo}</p>
                        {cliente && <p className="text-xs text-gray-500 mt-0.5">{cliente.nome}</p>}
                      </div>
                    )
                  })}
                </div>
              )}
            </>
          ) : (
            <div className="text-center py-12 text-gray-400">
              <Calendar className="w-10 h-10 mx-auto mb-3 opacity-40" />
              <p className="text-sm font-medium">Selecione uma data</p>
              <p className="text-xs mt-1">Clique em um dia para ver os vídeos</p>
            </div>
          )}
        </div>
      </div>

      <div className="flex items-center gap-4 text-xs text-gray-500">
        {clientes.map(c => (
          <div key={c.id} className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: c.cor }} />
            <span>{c.nome}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
