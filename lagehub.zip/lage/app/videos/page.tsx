"use client";

import { useState, useMemo } from "react";
import { videos, clientes } from "@/lib/mock-data";
import { getStatusColor, getTipoColor, getInitials } from "@/lib/utils";
import { Search, Upload, Plus, ExternalLink, Edit2, Trash2, ChevronLeft, ChevronRight } from "lucide-react";

const MESES = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
const TODOS_STATUS = ["Publicado", "Rascunho", "Atrasado", "Pausado", "Postergado", "Em Progresso", "Concluído"];
const PER_PAGE = 20;

export default function VideosPage() {
  const [clienteFilter, setClienteFilter] = useState("");
  const [mesFilter, setMesFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);

  const filtered = useMemo(() => {
    return videos.filter((v) => {
      if (clienteFilter && v.clienteId !== clienteFilter) return false;
      if (mesFilter && v.dataPostagem) {
        const mes = new Date(v.dataPostagem).getMonth();
        if (String(mes) !== mesFilter) return false;
      }
      if (statusFilter && v.status !== statusFilter) return false;
      if (search && !v.titulo.toLowerCase().includes(search.toLowerCase())) return false;
      return true;
    });
  }, [clienteFilter, mesFilter, statusFilter, search]);

  const totalPages = Math.ceil(filtered.length / PER_PAGE);
  const paginated = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Vídeos</h1>
          <p className="text-gray-400 text-sm">Gerencia todos os vídeos do sistema</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-lg text-sm text-gray-600 hover:bg-gray-50 transition-colors">
            <Upload size={15} />
            Importar CSV
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-violet-600 text-white rounded-lg text-sm hover:bg-violet-700 transition-colors">
            <Plus size={15} />
            Novo Vídeo
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl border border-gray-100 p-4 mb-4 shadow-sm">
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex-1 flex items-center gap-2 border border-gray-200 rounded-lg px-3 py-2 min-w-48">
            <Search size={14} className="text-gray-400" />
            <input
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              placeholder="Buscar vídeo..."
              className="bg-transparent text-sm outline-none flex-1 text-gray-700 placeholder:text-gray-400"
            />
          </div>
          <select
            value={clienteFilter}
            onChange={(e) => { setClienteFilter(e.target.value); setPage(1); }}
            className="border border-gray-200 rounded-lg px-3 py-2 text-sm text-gray-700 outline-none bg-white"
          >
            <option value="">Todos os clientes</option>
            {clientes.map((c) => <option key={c.id} value={c.id}>{c.nome}</option>)}
          </select>
          <select
            value={mesFilter}
            onChange={(e) => { setMesFilter(e.target.value); setPage(1); }}
            className="border border-gray-200 rounded-lg px-3 py-2 text-sm text-gray-700 outline-none bg-white"
          >
            <option value="">Todos os meses</option>
            {MESES.map((m, i) => <option key={i} value={String(i)}>{m}</option>)}
          </select>
          <select
            value={statusFilter}
            onChange={(e) => { setStatusFilter(e.target.value); setPage(1); }}
            className="border border-gray-200 rounded-lg px-3 py-2 text-sm text-gray-700 outline-none bg-white"
          >
            <option value="">Todos os status</option>
            {TODOS_STATUS.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      </div>

      <p className="text-gray-400 text-xs mb-3">
        Mostrando {paginated.length} de {filtered.length} vídeos ({videos.length} total)
      </p>

      {/* Table */}
      <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-100 bg-gray-50">
                <th className="text-left px-4 py-3 text-gray-500 font-medium text-xs w-20">Thumbnail</th>
                <th className="text-left px-4 py-3 text-gray-500 font-medium text-xs">Título</th>
                <th className="text-left px-4 py-3 text-gray-500 font-medium text-xs">Tipo</th>
                <th className="text-left px-4 py-3 text-gray-500 font-medium text-xs">Edição</th>
                <th className="text-left px-4 py-3 text-gray-500 font-medium text-xs">Data de Postagem</th>
                <th className="text-left px-4 py-3 text-gray-500 font-medium text-xs">Status</th>
                <th className="text-left px-4 py-3 text-gray-500 font-medium text-xs">Ações</th>
              </tr>
            </thead>
            <tbody>
              {paginated.map((v) => {
                const cliente = clientes.find((c) => c.id === v.clienteId);
                return (
                  <tr key={v.id} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3">
                      <div className="w-14 h-9 rounded bg-gray-200 flex items-center justify-center overflow-hidden">
                        {v.thumbnail ? (
                          <img src={v.thumbnail} alt="" className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full rounded flex items-center justify-center" style={{ backgroundColor: cliente?.cor + "30" }}>
                            <span className="text-xs font-bold" style={{ color: cliente?.cor }}>{getInitials(cliente?.nome || "")}</span>
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div>
                        <p className="text-gray-800 font-medium line-clamp-2 max-w-xs">{v.titulo}</p>
                        <p className="text-xs text-gray-400 mt-0.5">{cliente?.nome}</p>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getTipoColor(v.tipoConteudo)}`}>
                        {v.tipoConteudo}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-gray-600 text-xs">{v.edicao || "—"}</span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-gray-600 text-xs">
                        {v.dataPostagem ? new Date(v.dataPostagem).toLocaleDateString("pt-BR") : "—"}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColor(v.status)}`}>
                        {v.status}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        {v.linkVideo && (
                          <button className="p-1.5 rounded hover:bg-gray-100 transition-colors">
                            <ExternalLink size={13} className="text-gray-400" />
                          </button>
                        )}
                        <button className="p-1.5 rounded hover:bg-gray-100 transition-colors">
                          <Edit2 size={13} className="text-gray-400" />
                        </button>
                        <button className="p-1.5 rounded hover:bg-red-50 transition-colors">
                          <Trash2 size={13} className="text-red-400" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-gray-100">
            <span className="text-xs text-gray-400">Página {page} de {totalPages}</span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setPage(p => Math.max(1, p - 1))}
                disabled={page === 1}
                className="p-1.5 rounded hover:bg-gray-100 disabled:opacity-40 transition-colors"
              >
                <ChevronLeft size={15} />
              </button>
              <button
                onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
                className="p-1.5 rounded hover:bg-gray-100 disabled:opacity-40 transition-colors"
              >
                <ChevronRight size={15} />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
