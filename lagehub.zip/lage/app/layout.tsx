import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Sidebar } from "@/components/layout/Sidebar";
import { Header } from "@/components/layout/Header";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Lage Hub",
  description: "Sistema de gestão de canais do YouTube",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body className={inter.className}>
        <Sidebar />
        <Header />
        <main className="ml-56 mt-14 min-h-screen bg-gray-50">
          {children}
        </main>
      </body>
    </html>
  );
}
