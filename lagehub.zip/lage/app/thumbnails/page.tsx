export default function ThumbnailsPage() {
  const thumbs = Array.from({ length: 12 }, (_, i) => ({ id: i + 1, title: `Thumbnail ${i + 1}` }))
  return (
    <div className="p-6 space-y-5">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Repositório de Thumbs</h1>
        <p className="text-sm text-gray-500 mt-1">Biblioteca de thumbnails dos canais</p>
      </div>
      <div className="grid grid-cols-4 gap-4">
        {thumbs.map(t => (
          <div key={t.id} className="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-md transition-shadow cursor-pointer">
            <div className="aspect-video bg-gray-100 flex items-center justify-center">
              <span className="text-gray-300 text-4xl">🖼️</span>
            </div>
            <div className="p-3">
              <p className="text-sm font-medium text-gray-700">{t.title}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
