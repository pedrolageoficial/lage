'use client'

import { useState } from 'react'
import { Plus, List, Columns } from 'lucide-react'
import { tarefas, clientes } from '@/lib/mock-data'
import { getClienteById, getTipoColor, getStatusColor } from '@/lib/utils'
import { format } from 'date-fns'
import { StatusTarefa } from '@/types'

const COLUMNS: { key: StatusTarefa; label: string; color: string }[] = [
  { key: 'Pendente', label: 'Pendente', color: 'bg-gray-100 text-gray-700' },
  { key: 'Em Progresso', label: 'Em Progresso', color: 'bg-blue-100 text-blue-700' },
  { key: 'Concluído', label: 'Concluído', color: 'bg-green-100 text-green-700' },
  { key: 'Atrasado', label: 'Atrasado', color: 'bg-red-100 text-red-700' },
]

export default function TarefasPage() {
  const [view, setView] = useState<'list' | 'kanban'>('kanban')

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Minhas Tarefas</h1>
          <p className="text-sm text-gray-500 mt-1">Gerencie e acompanhe suas tarefas</p>
        </div>
        <div className="flex gap-2">
          <div className="flex border border-gray-200 rounded-lg overflow-hidden">
            <button onClick={() => setView('list')} className={`p-2 ${view === 'list' ? 'bg-violet-600 text-white' : 'text-gray-500 hover:bg-gray-50'} transition-colors`}>
              <List className="w-4 h-4" />
            </button>
            <button onClick={() => setView('kanban')} className={`p-2 ${view === 'kanban' ? 'bg-violet-600 text-white' : 'text-gray-500 hover:bg-gray-50'} transition-colors`}>
              <Columns className="w-4 h-4" />
            </button>
          </div>
          <button className="flex items-center gap-2 bg-violet-600 hover:bg-violet-700 text-white px-4 py-2 rounded-lg text-sm transition-colors">
            <Plus className="w-4 h-4" /> Nova Tarefa
          </button>
        </div>
      </div>

      {view === 'kanban' ? (
        <div className="grid grid-cols-4 gap-4">
          {COLUMNS.map(col => {
            const colTasks = tarefas.filter(t => t.status === col.key)
            return (
              <div key={col.key} className="bg-gray-50 rounded-xl p-3">
                <div className="flex items-center justify-between mb-3">
                  <span className={`text-xs font-semibold px-2 py-1 rounded-full ${col.color}`}>{col.label}</span>
                  <span className="text-xs text-gray-400 font-medium">{colTasks.length}</span>
                </div>
                <div className="space-y-2">
                  {colTasks.map(t => {
                    const cliente = getClienteById(clientes, t.clienteId)
                    return (
                      <div key={t.id} className="bg-white rounded-lg p-3 border border-gray-200 hover:shadow-sm transition-shadow cursor-pointer">
                        <div className="flex items-center justify-between mb-2">
                          <span className={`text-xs px-1.5 py-0.5 rounded font-medium ${
                            t.prioridade === 'Alta' ? 'bg-red-100 text-red-700' :
                            t.prioridade === 'Média' ? 'bg-yellow-100 text-yellow-700' :
                            'bg-green-100 text-green-700'
                          }`}>{t.prioridade}</span>
                          <span className={`text-xs px-1.5 py-0.5 rounded font-medium ${getTipoColor(t.tipo)}`}>{t.tipo}</span>
                        </div>
                        <p className="text-sm font-medium text-gray-800 mb-1">{t.titulo}</p>
                        {cliente && <p className="text-xs text-gray-500">{cliente.nome}</p>}
                        {t.prazo && (
                          <p className="text-xs text-gray-400 mt-1">
                            {format(new Date(t.prazo), 'dd/MM/yyyy')}
                          </p>
                        )}
                      </div>
                    )
                  })}
                </div>
              </div>
            )
          })}
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr className="text-left text-xs text-gray-500 font-medium">
                <th className="px-4 py-3">Tarefa</th>
                <th className="px-4 py-3">Cliente</th>
                <th className="px-4 py-3">Tipo</th>
                <th className="px-4 py-3">Prazo</th>
                <th className="px-4 py-3">Prioridade</th>
                <th className="px-4 py-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {tarefas.map(t => {
                const cliente = getClienteById(clientes, t.clienteId)
                return (
                  <tr key={t.id} className="hover:bg-gray-50 text-sm">
                    <td className="px-4 py-3 font-medium text-gray-800">{t.titulo}</td>
                    <td className="px-4 py-3 text-gray-600">{cliente?.nome || '-'}</td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${getTipoColor(t.tipo)}`}>{t.tipo}</span>
                    </td>
                    <td className="px-4 py-3 text-gray-500">{t.prazo ? format(new Date(t.prazo), 'dd/MM/yyyy') : '-'}</td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                        t.prioridade === 'Alta' ? 'bg-red-100 text-red-700' :
                        t.prioridade === 'Média' ? 'bg-yellow-100 text-yellow-700' :
                        'bg-green-100 text-green-700'
                      }`}>{t.prioridade}</span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${getStatusColor(t.status)}`}>{t.status}</span>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
