export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-gray-900 mb-1">Configurações</h1>
      <p className="text-gray-400 text-sm mb-8">Configure o sistema</p>
      <div className="bg-white rounded-xl border border-gray-100 shadow-sm flex flex-col items-center justify-center py-24">
        <div className="w-16 h-16 bg-violet-100 rounded-full flex items-center justify-center mb-4">
          <span className="text-3xl">🚀</span>
        </div>
        <h2 className="text-lg font-semibold text-gray-700 mb-2">Em construção</h2>
        <p className="text-gray-400 text-sm">Esta seção estará disponível em breve.</p>
      </div>
    </div>
  );
}
