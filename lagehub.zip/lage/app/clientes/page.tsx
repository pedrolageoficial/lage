import { Plus } from 'lucide-react'
import { clientes, videos } from '@/lib/mock-data'
import { getInitials } from '@/lib/utils'

export default function ClientesPage() {
  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Clientes</h1>
          <p className="text-sm text-gray-500 mt-1">Gerencie seus clientes e canais</p>
        </div>
        <button className="flex items-center gap-2 bg-violet-600 hover:bg-violet-700 text-white px-4 py-2 rounded-lg text-sm transition-colors">
          <Plus className="w-4 h-4" /> Novo Cliente
        </button>
      </div>
      <div className="grid grid-cols-3 gap-4">
        {clientes.map(c => {
          const videoCount = videos.filter(v => v.clienteId === c.id).length
          return (
            <div key={c.id} className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-md transition-shadow cursor-pointer">
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full flex items-center justify-center text-white text-xl font-bold mb-3"
                  style={{ backgroundColor: c.cor }}>
                  {getInitials(c.nome)}
                </div>
                <h3 className="font-bold text-gray-900 text-lg">{c.nome}</h3>
                <p className="text-sm text-gray-500 mt-0.5">{c.canal}</p>
                <p className="text-sm text-gray-600 mt-2"><strong>{videoCount}</strong> vídeos</p>
                <span className={`mt-3 text-xs px-3 py-1 rounded-full font-medium ${c.ativo ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                  {c.ativo ? 'Ativo' : 'Inativo'}
                </span>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
