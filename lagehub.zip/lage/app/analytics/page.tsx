export default function Page() {
  return (
    <div className="p-6 flex flex-col items-center justify-center h-64 text-gray-400">
      <div className="text-6xl mb-4">🚧</div>
      <h2 className="text-xl font-semibold text-gray-600">Em construção</h2>
      <p className="text-sm mt-2">Esta página estará disponível em breve.</p>
    </div>
  )
}
