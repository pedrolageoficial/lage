export interface Cliente {
  id: string;
  nome: string;
  canal: string;
  cor: string;
  ativo: boolean;
}

export type StatusVideo = "Publicado" | "Rascunho" | "Atrasado" | "Pausado" | "Postergado" | "Em Progresso" | "Concluído";
export type TipoConteudo = "Talking Head" | "Dark Discovery" | "Vlog" | "Nativo" | "Não definido";
export type EstagioPipeline = "Embalagem" | "Aprovação Big Idea" | "Gravação" | "Roteiro" | "Postagem" | "Gravação e Mineração" | "Edição" | "Aprovação Roteiro" | "Concluído";

export interface Video {
  id: string;
  titulo: string;
  clienteId: string;
  tipoConteudo: TipoConteudo;
  edicao?: string;
  dataPostagem?: string;
  status: StatusVideo;
  estagio: EstagioPipeline;
  thumbnail?: string;
  linkVideo?: string;
  bigIdea?: string;
  criadoEm: string;
}

export type StatusTarefa = "Pendente" | "Em Progresso" | "Concluído" | "Atrasado";
export type PrioridadeTarefa = "Baixa" | "Média" | "Alta";

export interface Tarefa {
  id: string;
  titulo: string;
  clienteId: string;
  videoId?: string;
  tipo: string;
  prazo?: string;
  status: StatusTarefa;
  responsavel?: string;
  prioridade: PrioridadeTarefa;
}
