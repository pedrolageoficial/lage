import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { Cliente } from '@/types'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function getStatusColor(status: string): string {
  switch (status) {
    case 'Publicado': return 'bg-green-100 text-green-700'
    case 'Concluído': return 'bg-green-100 text-green-700'
    case 'Em Progresso': return 'bg-blue-100 text-blue-700'
    case 'Rascunho': return 'bg-gray-100 text-gray-700'
    case 'Atrasado': return 'bg-red-100 text-red-700'
    case 'Pausado': return 'bg-yellow-100 text-yellow-700'
    case 'Postergado': return 'bg-orange-100 text-orange-700'
    case 'Pendente': return 'bg-gray-100 text-gray-700'
    default: return 'bg-gray-100 text-gray-600'
  }
}

export function getTipoColor(tipo: string): string {
  switch (tipo) {
    case 'Talking Head': return 'bg-blue-100 text-blue-700'
    case 'Dark Discovery': return 'bg-purple-100 text-purple-700'
    case 'Vlog': return 'bg-orange-100 text-orange-700'
    case 'Nativo': return 'bg-green-100 text-green-700'
    case 'Não definido': return 'bg-gray-100 text-gray-600'
    default: return 'bg-gray-100 text-gray-600'
  }
}

export function getClienteById(clientes: Cliente[], id: string): Cliente | undefined {
  return clientes.find(c => c.id === id)
}

export function getInitials(nome: string): string {
  return nome
    .split(' ')
    .slice(0, 2)
    .map(n => n[0])
    .join('')
    .toUpperCase()
}
