"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard, Video, Image, Users, BarChart2, CheckSquare,
  Calendar, FileText, GitBranch, UserCog, TrendingUp, Bot,
  ClipboardCheck, Zap, DollarSign, Mic, Globe, Settings, LogOut
} from "lucide-react";

const menuPrincipal = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/videos", label: "Vídeos", icon: Video },
  { href: "/thumbnails", label: "Repositório de Thumbs", icon: Image },
  { href: "/clientes", label: "Clientes", icon: Users },
  { href: "/relatorios", label: "Relatórios", icon: BarChart2 },
  { href: "/tarefas", label: "Minhas Tarefas", icon: CheckSquare },
  { href: "/calendario", label: "Calendário", icon: Calendar },
];

const administracao = [
  { href: "/templates", label: "Templates", icon: FileText },
  { href: "/pipelines", label: "Pipelines", icon: GitBranch },
  { href: "/usuarios", label: "Usuários", icon: UserCog },
  { href: "/analytics", label: "Analytics", icon: TrendingUp },
  { href: "/ai", label: "AI Assistant", icon: Bot },
  { href: "/validacao", label: "Validação de Tarefas", icon: ClipboardCheck },
];

const ferramentas = [
  { href: "#", label: "Premise Forge", icon: Zap },
  { href: "#", label: "Spend Flow", icon: DollarSign },
  { href: "#", label: "Lutz Podcast Hub", icon: Mic },
  { href: "#", label: "Site Institucional", icon: Globe },
];

export function Sidebar() {
  const pathname = usePathname();

  const NavItem = ({ href, label, icon: Icon }: { href: string; label: string; icon: React.ElementType }) => {
    const active = pathname === href;
    return (
      <Link
        href={href}
        className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors ${
          active
            ? "bg-violet-600 text-white font-medium"
            : "text-gray-400 hover:text-white hover:bg-gray-800"
        }`}
      >
        <Icon size={16} />
        <span>{label}</span>
      </Link>
    );
  };

  return (
    <aside className="fixed left-0 top-0 bottom-0 w-56 bg-gray-950 border-r border-gray-800 flex flex-col z-40">
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 py-4 border-b border-gray-800">
        <div className="w-8 h-8 bg-violet-600 rounded-lg flex items-center justify-center">
          <span className="text-white font-bold text-sm">L</span>
        </div>
        <span className="text-white font-bold text-base">Lage Hub</span>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto px-3 py-3 space-y-4">
        <div>
          <p className="text-gray-500 text-xs font-semibold uppercase tracking-wider px-3 mb-2">Menu Principal</p>
          <div className="space-y-0.5">
            {menuPrincipal.map((item) => (
              <NavItem key={item.href} {...item} />
            ))}
          </div>
        </div>

        <div>
          <p className="text-gray-500 text-xs font-semibold uppercase tracking-wider px-3 mb-2">Administração</p>
          <div className="space-y-0.5">
            {administracao.map((item) => (
              <NavItem key={item.href} {...item} />
            ))}
          </div>
        </div>

        <div>
          <p className="text-gray-500 text-xs font-semibold uppercase tracking-wider px-3 mb-2">Ferramentas</p>
          <div className="space-y-0.5">
            {ferramentas.map((item) => (
              <NavItem key={item.href} {...item} />
            ))}
          </div>
        </div>
      </nav>

      {/* Footer */}
      <div className="px-3 py-3 border-t border-gray-800 space-y-0.5">
        <p className="text-gray-600 text-xs px-3 mb-2">Versão 1.0.0</p>
        <NavItem href="/configuracoes" label="Configurações" icon={Settings} />
        <button className="flex items-center gap-3 px-3 py-2 rounded-md text-sm text-red-400 hover:bg-gray-800 w-full transition-colors">
          <LogOut size={16} />
          <span>Sair</span>
        </button>
      </div>
    </aside>
  );
}
