"use client";

import { Bell, Search } from "lucide-react";

export function Header() {
  return (
    <header className="fixed top-0 left-56 right-0 h-14 bg-white border-b border-gray-200 flex items-center px-4 gap-4 z-30">
      <div className="flex-1 flex items-center gap-2 bg-gray-100 rounded-lg px-3 py-2 max-w-md">
        <Search size={16} className="text-gray-400" />
        <input
          type="text"
          placeholder="Buscar vídeos e tarefas..."
          className="bg-transparent text-sm text-gray-700 outline-none flex-1 placeholder:text-gray-400"
        />
      </div>
      <div className="flex items-center gap-3 ml-auto">
        <button className="p-2 rounded-lg hover:bg-gray-100 transition-colors">
          <Bell size={18} className="text-gray-500" />
        </button>
        <div className="w-8 h-8 bg-violet-600 rounded-full flex items-center justify-center">
          <span className="text-white font-bold text-xs">PL</span>
        </div>
      </div>
    </header>
  );
}
